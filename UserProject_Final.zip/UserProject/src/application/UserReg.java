package application;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Background;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class UserReg<E> implements Initializable {

	@FXML
    private Pane pane;
	
	@FXML
    private Button btnReg;
	
	@FXML
    private Button btnLogin;
	
	@FXML
    private TextField fn;
	
	@FXML
    private TextField mn;
	
    @FXML
    private TextField ln;
    
    @FXML
    private PasswordField txtPass;
    
    @FXML
    private TextField ph;

    @FXML
    private TextField email;
    
    @FXML
    private TextArea add;

    @FXML
    private DatePicker bDate;

    @FXML
    private RadioButton rMale;

    @FXML
    private ToggleGroup gender;

    @FXML
    private RadioButton rFemale;

    @FXML
    private RadioButton rOther;

    @FXML
    private TextField age;

    @FXML
    public ComboBox<String> city;
    
    @FXML
    void Loginfun(ActionEvent event) {
    	new LoginPage().start(RegPage.primaryStage);
    	
    }

    @FXML
    void Register(ActionEvent event) {
    	
    	try{

    		String name = (fn.getText() + " " + mn.getText() + " " + ln.getText());
    		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy",Locale.US);
    		String bdate = (bDate.getValue()).format(formatter);
    		
    		if (name != null || txtPass.getText() != null || bdate != null) {
    			RadioButton selectedRadioButton = (RadioButton) gender.getSelectedToggle();
        		String gen = selectedRadioButton.getText();
    			Writer store = new BufferedWriter(new FileWriter("C:\\Users\\HP\\eclipse-workspace\\UserProject\\src\\application\\Users.txt", true));
    			store.append(name);
    			store.append("#");
    			store.append(txtPass.getText().toString());
    			store.append("#");
    			store.append(ph.getText().toString());
    			store.append("#");
    			store.append(email.getText().toString());
    			store.append("#");
    			store.append(add.getText().toString());
    			store.append("#");
    			store.append(bdate);
    			store.append("#");
    			store.append(gen);
    			store.append("#");
    			store.append(age.getText());
    			store.append("#");
    			store.append(city.getValue());
    			store.append("$");
    			store.append(System.lineSeparator());
    			store.close();
    			new Dashboard().start(RegPage.primaryStage);
    		}
					
    		else {
    			Label war = new Label();
    			war.setText("Enter Data");
    			war.setFont(new Font(45));
    			war.setTextFill(Color.RED);
    			pane.getChildren().add(war);
    		}
    		 
    	}catch (Exception e){
    		  System.err.println("Error: " + e.getMessage());
    	}
    }

	@Override
	public void initialize(URL location, ResourceBundle resourses) {
		
		city.getItems().addAll("Rajkot", "Jamnagar", "Abad", "Surat", "Dwarka", "Vadodara");
	}

}