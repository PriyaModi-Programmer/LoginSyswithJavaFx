package application;

import java.io.BufferedReader;
import java.io.FileReader;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class UserLogin {

    @FXML
    private TextField txtUsername;

    @FXML
    private Button btnLogin;

    @FXML
    private PasswordField textPass;

    @FXML
    private Button btnReg;

    @FXML
    void Loginfun(ActionEvent event) {

    	try {
			BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\HP\\eclipse-workspace\\UserProject\\src\\application\\Users.txt"));
			String temp;
			boolean isValid = false;
			while((temp = br.readLine())!=null) {
				String[] up = temp.split("#");
				if(txtUsername.getText().equals(up[0])) {
					if(textPass.getText().equals(up[1])) {
						isValid = true;
						break;
					}
				}
			}
			if(isValid) {
				new Dashboard().start(LoginPage.primaryStage);
			}
			else {
				System.out.println("Invalid User");
			}
			br.close();
			
		} catch (Exception e) {

			e.printStackTrace();
		}
    }

    @FXML
    void Register(ActionEvent event) {
    	
    	try {
			new RegPage().start(LoginPage.primaryStage);
		} catch (Exception e) {

			e.printStackTrace();
		}
    }

}