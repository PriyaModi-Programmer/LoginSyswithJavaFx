package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class RegPage extends Application {

public static void main(String[] args) {
		
		launch(args);
	}

	public static Stage primaryStage;

    @SuppressWarnings("rawtypes")
	@Override
    public void start(Stage primaryStage) {

        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Registration Page");

        try {
            
            FXMLLoader loader = new FXMLLoader();
            loader.setController(new UserReg());
            loader.setLocation(LoginPage.class.getResource("UserReg.fxml"));
            Pane root = loader.load();

            Scene scene = new Scene(root);
            this.primaryStage.setScene(scene);
            this.primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
