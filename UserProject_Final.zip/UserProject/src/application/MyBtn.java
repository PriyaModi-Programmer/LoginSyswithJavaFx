package application;

import javafx.scene.control.Button;
import javafx.scene.text.TextAlignment;

public class MyBtn extends Button{
	
	public MyBtn(String name) { 
		
		super(name);
		this.setOpacity(0.5);
		this.setMaxWidth(600);
		this.setMaxHeight(500);
		this.setTextAlignment(TextAlignment.CENTER);
	}
}
