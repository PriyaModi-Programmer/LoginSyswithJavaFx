package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

public class UserDashboard {
	
	String[] spStr;	String ur1;
	
	@FXML
    private VBox vb;
	
    @FXML
    void initialize(){
		
    	BufferedReader br;
    	String line;
    	List<String> u = new ArrayList<String>();
		try {
			br = new BufferedReader(new FileReader("C:\\Users\\HP\\eclipse-workspace\\UserProject\\src\\application\\Users.txt")); 
			String[] records = new String[10];
			int i = 0;
			
			while((line = br.readLine()) != null)  {  
				records[i] = line;
				String[] user = records[i].split("#");
				u.add(user[0]);
				MyBtn ur = new MyBtn(u.get(i));
				ur.setId(u.get(i));
				vb.getChildren().add(ur);
				i++;
				
			ur.setOnMouseClicked(new EventHandler<Event>() {

				@Override
				public void handle(Event arg0) {
					int j=0;	String line;
					try {
						while ((line = br.readLine()) != null) {
							if (u.get(j).toString() == ur.getId().toString()) {
								records[j] = line;
								String[] user = records[j].split("#");
								u.add(user[j]);
								System.out.println(u.get(0));
								j++;
							} 
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			}			
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
    }
    
}