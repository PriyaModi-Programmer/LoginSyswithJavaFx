package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LoginPage extends Application {

	public static void main(String[] args) {
		
		launch(args);
	}

	public static Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {

        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Login Page");

        try {
            
            FXMLLoader loader = new FXMLLoader();
            loader.setController(new UserLogin());
            loader.setLocation(LoginPage.class.getResource("UserLogin.fxml"));
            Pane root = loader.load();

            Scene scene = new Scene(root);
            this.primaryStage.setScene(scene);
            this.primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
