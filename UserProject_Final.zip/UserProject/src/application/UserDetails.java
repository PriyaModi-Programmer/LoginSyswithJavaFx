package application;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;

public class UserDetails {

    @FXML
    private Pane pane;

    @FXML
    public static Pane detail;
    
}

