package application;
	
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;


public class FileDemo extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Label lblAns = new Label("");
			lblAns.setLayoutX(60);
			lblAns.setLayoutY(0);
			lblAns.setFont(new Font(30));
			
			TextField txtUserName = new TextField();
			txtUserName.setLayoutX(30);
			txtUserName.setLayoutY(30);
			
			TextField txtPassword = new TextField();
			txtPassword.setLayoutX(30);
			txtPassword.setLayoutY(80);
			
			Button btnLogin = new Button("Login");
			btnLogin.setLayoutX(60);
			btnLogin.setLayoutY(130);
			
			btnLogin.setOnAction(new EventHandler<ActionEvent>() {
				
				@Override
				public void handle(ActionEvent arg0) {
					// TODO Auto-generated method stub
					// byte stream (byte by byte) => FileInputStream
					// char stream (char by char) => Scanner, BufferedReader
					
					try {
						BufferedReader br = new BufferedReader(new FileReader("D:\\MediaDemo\\Users.txt"));
						String temp;
						boolean isValid = false;
						while((temp = br.readLine())!=null) {
							String[] up = temp.split("#");
							if(txtUserName.getText().equals(up[0])) {
								if(txtPassword.getText().equals(up[1])) {
									isValid = true;
									break;
								}
							}
						}
						if(isValid) {
							lblAns.setText("Valid User");
						}
						else {
							lblAns.setText("Invalid User");
						}
						br.close();
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			
			Button btnReg = new Button("Register");
			btnReg.setLayoutX(120);
			btnReg.setLayoutY(130);
			
			btnReg.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent arg0) {
					// TODO Auto-generated method stub
					try {
						File file = new File("D:\\MediaDemo\\Users.txt");
						FileWriter fr = new FileWriter(file,true);
						BufferedWriter br = new BufferedWriter(fr);
						PrintWriter pw = new PrintWriter(br);
						String temp = "\n"+txtUserName.getText() + "#" + txtPassword.getText();
						pw.append(temp);
						
						pw.close();
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			
			Group root = new Group(txtUserName,txtPassword,btnLogin,lblAns,btnReg);
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}